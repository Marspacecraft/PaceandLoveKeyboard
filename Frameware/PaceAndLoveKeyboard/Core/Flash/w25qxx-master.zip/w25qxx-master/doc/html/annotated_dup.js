var annotated_dup =
[
    [ "w25qxx_handle_s", "structw25qxx__handle__s.html", "structw25qxx__handle__s" ],
    [ "w25qxx_info_s", "structw25qxx__info__s.html", "structw25qxx__info__s" ]
];