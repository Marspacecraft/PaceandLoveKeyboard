var group__w25qxx__extern__driver =
[
    [ "w25qxx_write_read_reg", "group__w25qxx__extern__driver.html#ga9623a3bec148b148498480518a66cb2b", null ]
];