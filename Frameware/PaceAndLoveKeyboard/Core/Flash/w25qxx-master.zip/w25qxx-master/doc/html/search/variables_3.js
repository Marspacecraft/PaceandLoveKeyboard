var searchData=
[
  ['debug_5fprint_430',['debug_print',['../structw25qxx__handle__s.html#a769d5b3a6c14790a0e126e8fe70b384b',1,'w25qxx_handle_s']]],
  ['delay_5fms_431',['delay_ms',['../structw25qxx__handle__s.html#a406c9433252b7366de417b7a60915c81',1,'w25qxx_handle_s']]],
  ['delay_5fus_432',['delay_us',['../structw25qxx__handle__s.html#a97ffc4fce945527bd6ab25a3596caef7',1,'w25qxx_handle_s']]],
  ['driver_5fversion_433',['driver_version',['../structw25qxx__info__s.html#a41b0bd442708b70d252c50b92c75265a',1,'w25qxx_info_s']]],
  ['dual_5fquad_5fspi_5fenable_434',['dual_quad_spi_enable',['../structw25qxx__handle__s.html#ac2bd5f4f7f52f548fd421c9eedbce1c7',1,'w25qxx_handle_s']]],
  ['dummy_435',['dummy',['../structw25qxx__handle__s.html#aff7b59f569ec689a7580bd6911daafd5',1,'w25qxx_handle_s']]]
];
