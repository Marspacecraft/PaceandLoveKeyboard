var searchData=
[
  ['w25qxx_5fhandle_5fs_292',['w25qxx_handle_s',['../structw25qxx__handle__s.html',1,'']]],
  ['w25qxx_5finfo_5fs_293',['w25qxx_info_s',['../structw25qxx__info__s.html',1,'']]]
];
