var group__w25qxx__link__driver =
[
    [ "DRIVER_W25QXX_LINK_DEBUG_PRINT", "group__w25qxx__link__driver.html#gab8d49ef9dca942fe5f37c30dcd7e22a6", null ],
    [ "DRIVER_W25QXX_LINK_DELAY_MS", "group__w25qxx__link__driver.html#ga7555618f13d2de0003ae6d9483085180", null ],
    [ "DRIVER_W25QXX_LINK_DELAY_US", "group__w25qxx__link__driver.html#gafc81bf850c80dfa316f0c6ab40be6e67", null ],
    [ "DRIVER_W25QXX_LINK_INIT", "group__w25qxx__link__driver.html#ga995378489f95bc6bbddbe710557e3384", null ],
    [ "DRIVER_W25QXX_LINK_SPI_QSPI_DEINIT", "group__w25qxx__link__driver.html#gaec8b55e83b46907be1dd9e7c50be550d", null ],
    [ "DRIVER_W25QXX_LINK_SPI_QSPI_INIT", "group__w25qxx__link__driver.html#gab2587de93f1dba5664eede8cd787a88a", null ],
    [ "DRIVER_W25QXX_LINK_SPI_QSPI_WRITE_READ", "group__w25qxx__link__driver.html#gac8f0ca0a725790bace3241d1d616e3d1", null ]
];