var searchData=
[
  ['spi_5fqspi_441',['spi_qspi',['../structw25qxx__handle__s.html#a9bdb5522ed967c80572351dd53dafe70',1,'w25qxx_handle_s']]],
  ['spi_5fqspi_5fdeinit_442',['spi_qspi_deinit',['../structw25qxx__handle__s.html#a4568e23228174b7d32678d9a96d2420c',1,'w25qxx_handle_s']]],
  ['spi_5fqspi_5finit_443',['spi_qspi_init',['../structw25qxx__handle__s.html#aec834df46e5185868dfdcc6fcec2e801',1,'w25qxx_handle_s']]],
  ['spi_5fqspi_5fwrite_5fread_444',['spi_qspi_write_read',['../structw25qxx__handle__s.html#a2d39cde883403779e3da9dd39c32bec5',1,'w25qxx_handle_s']]],
  ['supply_5fvoltage_5fmax_5fv_445',['supply_voltage_max_v',['../structw25qxx__info__s.html#a3d2b12bcac7a85ea8646bff9debe8660',1,'w25qxx_info_s']]],
  ['supply_5fvoltage_5fmin_5fv_446',['supply_voltage_min_v',['../structw25qxx__info__s.html#ad8bde6ddadaf43d951e62f3befb9d35a',1,'w25qxx_info_s']]]
];
