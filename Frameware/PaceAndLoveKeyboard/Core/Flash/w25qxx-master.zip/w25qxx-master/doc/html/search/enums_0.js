var searchData=
[
  ['w25qxx_5faddress_5fmode_5ft_452',['w25qxx_address_mode_t',['../group__w25qxx__basic__driver.html#gaa4c45f146d1ade8a2da8e751818fa4a2',1,'driver_w25qxx.h']]],
  ['w25qxx_5fbool_5ft_453',['w25qxx_bool_t',['../group__w25qxx__basic__driver.html#gafb2690946f5baf4be6f3a63dde5491fb',1,'driver_w25qxx.h']]],
  ['w25qxx_5fburst_5fwrap_5ft_454',['w25qxx_burst_wrap_t',['../group__w25qxx__advance__driver.html#ga94bbae2bf8906903e8dc2a28c490723d',1,'driver_w25qxx.h']]],
  ['w25qxx_5finterface_5ft_455',['w25qxx_interface_t',['../group__w25qxx__basic__driver.html#gacbf327a42336baf10713a1796ff4f2fe',1,'driver_w25qxx.h']]],
  ['w25qxx_5fqspi_5fread_5fdummy_5ft_456',['w25qxx_qspi_read_dummy_t',['../group__w25qxx__advance__driver.html#ga6ff284154302248f00db269146545443',1,'driver_w25qxx.h']]],
  ['w25qxx_5fqspi_5fread_5fwrap_5flength_5ft_457',['w25qxx_qspi_read_wrap_length_t',['../group__w25qxx__advance__driver.html#ga2fd3023819e1aebe089a4a72eb136da3',1,'driver_w25qxx.h']]],
  ['w25qxx_5fsecurity_5fregister_5ft_458',['w25qxx_security_register_t',['../group__w25qxx__advance__driver.html#ga81ddc7d4b9f4f124163beea19cc33c7e',1,'driver_w25qxx.h']]],
  ['w25qxx_5fstatus1_5ft_459',['w25qxx_status1_t',['../group__w25qxx__advance__driver.html#ga9e41a72d1e25d39d88ce7108a9b25595',1,'driver_w25qxx.h']]],
  ['w25qxx_5fstatus2_5ft_460',['w25qxx_status2_t',['../group__w25qxx__advance__driver.html#ga0d28076f6fc7d3ae9dd7f8410069a277',1,'driver_w25qxx.h']]],
  ['w25qxx_5fstatus3_5ft_461',['w25qxx_status3_t',['../group__w25qxx__advance__driver.html#gace18ebb2eac49cbde44a2935916f44ac',1,'driver_w25qxx.h']]],
  ['w25qxx_5ftype_5ft_462',['w25qxx_type_t',['../group__w25qxx__basic__driver.html#ga6cb4e5164464df549201dd96cb7a58b1',1,'driver_w25qxx.h']]]
];
