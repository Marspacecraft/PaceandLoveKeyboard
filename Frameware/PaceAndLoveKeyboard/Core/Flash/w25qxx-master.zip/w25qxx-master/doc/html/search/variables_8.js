var searchData=
[
  ['temperature_5fmax_447',['temperature_max',['../structw25qxx__info__s.html#a3366a5dce9b829e03c3d321c2b4df3f6',1,'w25qxx_info_s']]],
  ['temperature_5fmin_448',['temperature_min',['../structw25qxx__info__s.html#a8f9dbe66ac0b66ebae0a36fcb4ba368e',1,'w25qxx_info_s']]],
  ['type_449',['type',['../structw25qxx__handle__s.html#acb5cfd209ba75c853d03f701e7f91679',1,'w25qxx_handle_s']]]
];
