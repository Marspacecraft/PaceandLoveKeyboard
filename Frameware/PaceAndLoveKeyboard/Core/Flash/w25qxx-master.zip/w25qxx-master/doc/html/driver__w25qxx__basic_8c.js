var driver__w25qxx__basic_8c =
[
    [ "w25qxx_basic_chip_erase", "group__w25qxx__example__driver.html#gaf78e9f136e29b826c1a2b337b8451d6d", null ],
    [ "w25qxx_basic_deinit", "group__w25qxx__example__driver.html#gaeb167c2924a3490e9a8d11e0c57d2dc0", null ],
    [ "w25qxx_basic_get_id", "group__w25qxx__example__driver.html#gacdda3af55c024b55fc9939aa23650356", null ],
    [ "w25qxx_basic_init", "group__w25qxx__example__driver.html#ga1e20768311dfdf33c77b442fa874b61a", null ],
    [ "w25qxx_basic_power_down", "group__w25qxx__example__driver.html#ga572c9f7a0bf2e7ab43dc078121162ec3", null ],
    [ "w25qxx_basic_read", "group__w25qxx__example__driver.html#ga143fa1f19a792142339f3d4e9ce078d0", null ],
    [ "w25qxx_basic_wake_up", "group__w25qxx__example__driver.html#ga02914409a9db38f35bc89d9fc4d96a17", null ],
    [ "w25qxx_basic_write", "group__w25qxx__example__driver.html#ga5cf24fc78e1b45e845d02ec9133f46ab", null ]
];