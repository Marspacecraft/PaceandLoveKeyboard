var searchData=
[
  ['buf_427',['buf',['../structw25qxx__handle__s.html#a2121914a1858618e9216fa2daf0a42a2',1,'w25qxx_handle_s']]],
  ['buf_5f4k_428',['buf_4k',['../structw25qxx__handle__s.html#ac80aa2927adf500634749513e88c474b',1,'w25qxx_handle_s']]]
];
