var modules =
[
    [ "w25qxx driver function", "group__w25qxx__driver.html", "group__w25qxx__driver" ]
];