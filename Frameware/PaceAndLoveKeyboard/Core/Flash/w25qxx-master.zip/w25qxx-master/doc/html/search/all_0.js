var searchData=
[
  ['address_5fmode_0',['address_mode',['../structw25qxx__handle__s.html#a5aafa09a37ea9bdb7d3788ff5d39c729',1,'w25qxx_handle_s']]]
];
