var dir_b31d54d5631803016a26f28213a41162 =
[
    [ "driver_w25qxx_interface.h", "driver__w25qxx__interface_8h.html", "driver__w25qxx__interface_8h" ],
    [ "driver_w25qxx_interface_template.c", "driver__w25qxx__interface__template_8c.html", "driver__w25qxx__interface__template_8c" ]
];