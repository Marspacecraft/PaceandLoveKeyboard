var globals_func =
[
    [ "w", "globals_func.html", null ]
];