var files_dup =
[
    [ "doc", "dir_e68e8157741866f444e17edd764ebbae.html", "dir_e68e8157741866f444e17edd764ebbae" ],
    [ "example", "dir_cfafba98a580ce4b62f8a6fa96d7cbb0.html", "dir_cfafba98a580ce4b62f8a6fa96d7cbb0" ],
    [ "interface", "dir_b31d54d5631803016a26f28213a41162.html", "dir_b31d54d5631803016a26f28213a41162" ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ],
    [ "test", "dir_13e138d54eb8818da29c3992edef070a.html", "dir_13e138d54eb8818da29c3992edef070a" ]
];