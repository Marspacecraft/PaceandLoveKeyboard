var searchData=
[
  ['w25qxx_5fhandle_5ft_450',['w25qxx_handle_t',['../group__w25qxx__basic__driver.html#ga56d8a7b5f8b7eaed8df0b6dc90c266be',1,'driver_w25qxx.h']]],
  ['w25qxx_5finfo_5ft_451',['w25qxx_info_t',['../group__w25qxx__basic__driver.html#ga601d841ddd0ff8ad3ab52e07c679ef19',1,'driver_w25qxx.h']]]
];
