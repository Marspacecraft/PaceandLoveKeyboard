var searchData=
[
  ['inited_31',['inited',['../structw25qxx__handle__s.html#a19bedf28d2b9748f6a62d9ae93f4e68f',1,'w25qxx_handle_s']]],
  ['interface_32',['interface',['../structw25qxx__info__s.html#a5778305279cae46b2ecf862e97f73600',1,'w25qxx_info_s']]]
];
