var searchData=
[
  ['temperature_5fmax_48',['temperature_max',['../structw25qxx__info__s.html#a3366a5dce9b829e03c3d321c2b4df3f6',1,'w25qxx_info_s']]],
  ['temperature_5fmax_49',['TEMPERATURE_MAX',['../driver__w25qxx_8c.html#a90c0b20d54005712fcc8cb01281360e9',1,'driver_w25qxx.c']]],
  ['temperature_5fmin_50',['temperature_min',['../structw25qxx__info__s.html#a8f9dbe66ac0b66ebae0a36fcb4ba368e',1,'w25qxx_info_s']]],
  ['temperature_5fmin_51',['TEMPERATURE_MIN',['../driver__w25qxx_8c.html#aab353db5bf4eb787f86a2080f609a551',1,'driver_w25qxx.c']]],
  ['type_52',['type',['../structw25qxx__handle__s.html#acb5cfd209ba75c853d03f701e7f91679',1,'w25qxx_handle_s']]]
];
