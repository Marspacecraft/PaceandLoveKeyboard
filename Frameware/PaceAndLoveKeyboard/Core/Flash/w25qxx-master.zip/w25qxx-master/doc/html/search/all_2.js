var searchData=
[
  ['chip_5fname_3',['chip_name',['../structw25qxx__info__s.html#af890958c72bd715cc6454a10dc846ae6',1,'w25qxx_info_s']]],
  ['chip_5fname_4',['CHIP_NAME',['../driver__w25qxx_8c.html#adc9da0a24824ca1239b593f6459b3954',1,'driver_w25qxx.c']]]
];
