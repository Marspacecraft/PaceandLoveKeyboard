var structw25qxx__handle__s =
[
    [ "address_mode", "structw25qxx__handle__s.html#a5aafa09a37ea9bdb7d3788ff5d39c729", null ],
    [ "buf", "structw25qxx__handle__s.html#a2121914a1858618e9216fa2daf0a42a2", null ],
    [ "buf_4k", "structw25qxx__handle__s.html#ac80aa2927adf500634749513e88c474b", null ],
    [ "debug_print", "structw25qxx__handle__s.html#a769d5b3a6c14790a0e126e8fe70b384b", null ],
    [ "delay_ms", "structw25qxx__handle__s.html#a406c9433252b7366de417b7a60915c81", null ],
    [ "delay_us", "structw25qxx__handle__s.html#a97ffc4fce945527bd6ab25a3596caef7", null ],
    [ "dual_quad_spi_enable", "structw25qxx__handle__s.html#ac2bd5f4f7f52f548fd421c9eedbce1c7", null ],
    [ "dummy", "structw25qxx__handle__s.html#aff7b59f569ec689a7580bd6911daafd5", null ],
    [ "inited", "structw25qxx__handle__s.html#a19bedf28d2b9748f6a62d9ae93f4e68f", null ],
    [ "param", "structw25qxx__handle__s.html#a3d28993689552e18d554dc0644efcf16", null ],
    [ "spi_qspi", "structw25qxx__handle__s.html#a9bdb5522ed967c80572351dd53dafe70", null ],
    [ "spi_qspi_deinit", "structw25qxx__handle__s.html#a4568e23228174b7d32678d9a96d2420c", null ],
    [ "spi_qspi_init", "structw25qxx__handle__s.html#aec834df46e5185868dfdcc6fcec2e801", null ],
    [ "spi_qspi_write_read", "structw25qxx__handle__s.html#a2d39cde883403779e3da9dd39c32bec5", null ],
    [ "type", "structw25qxx__handle__s.html#acb5cfd209ba75c853d03f701e7f91679", null ]
];