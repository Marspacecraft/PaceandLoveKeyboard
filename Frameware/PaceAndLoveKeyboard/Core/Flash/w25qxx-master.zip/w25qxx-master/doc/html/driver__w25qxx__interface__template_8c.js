var driver__w25qxx__interface__template_8c =
[
    [ "w25qxx_interface_debug_print", "group__w25qxx__interface__driver.html#ga5325474fa17f6833744e631613fd2a0e", null ],
    [ "w25qxx_interface_delay_ms", "group__w25qxx__interface__driver.html#ga964fa232abf98737cb98458eebfff82c", null ],
    [ "w25qxx_interface_delay_us", "group__w25qxx__interface__driver.html#ga38e79039b913154c9dd1036ff52bb420", null ],
    [ "w25qxx_interface_spi_qspi_deinit", "group__w25qxx__interface__driver.html#ga091f3607fcdd47f9e5f94cf1397bd46a", null ],
    [ "w25qxx_interface_spi_qspi_init", "group__w25qxx__interface__driver.html#ga2bdc17a556f1c801a38656331f3bb7b6", null ],
    [ "w25qxx_interface_spi_qspi_write_read", "group__w25qxx__interface__driver.html#ga3d76ea1f431978f6b55edfd0628c94cd", null ]
];