var searchData=
[
  ['manufacturer_5fname_516',['MANUFACTURER_NAME',['../driver__w25qxx_8c.html#aaa2b8f5b105c3019df0cb346f472e803',1,'driver_w25qxx.c']]],
  ['max_5fcurrent_517',['MAX_CURRENT',['../driver__w25qxx_8c.html#a2989837a37d6d63b59c6dd541b785435',1,'driver_w25qxx.c']]]
];
