var searchData=
[
  ['manufacturer_5fname_438',['manufacturer_name',['../structw25qxx__info__s.html#ad25285dbf810c90f8eaf3fcef6f2b2ea',1,'w25qxx_info_s']]],
  ['max_5fcurrent_5fma_439',['max_current_ma',['../structw25qxx__info__s.html#a9db82802561bf22d799b03a345f1d1dc',1,'w25qxx_info_s']]]
];
