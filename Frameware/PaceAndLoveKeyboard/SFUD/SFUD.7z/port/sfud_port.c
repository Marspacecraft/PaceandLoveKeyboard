/*
 * This file is part of the Serial Flash Universal Driver Library.
 *
 * Copyright (c) 2016-2018, Armink, <armink.ztl@gmail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * 'Software'), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Function: Portable interface for each platform.
 * Created on: 2016-04-23
 */

#include <sfud.h>
#include <stdarg.h>
#include "main.h"
#include "spi.h"


#define W25X_WriteEnable		0x06
#define W25X_WriteDisable		0x04

typedef struct
{
	SPI_HandleTypeDef  *hspi;
	uint8_t lock;
}spi_alock_t;

#if 0
//W25QXXдʹ��
//��WEL��λ
void W25QXX_Write_Enable(void)
{
	uint8_t TxData,Rxdata;
	TxData = W25X_WriteEnable;
   	HAL_GPIO_WritePin(FLASH_CS_GPIO_Port, FLASH_CS_Pin, GPIO_PIN_RESET);	// cs on
	HAL_SPI_TransmitReceive(&FLASH_SPI_HANDLER,&TxData,&Rxdata,1, 1000);   //����дʹ��
   	HAL_GPIO_WritePin(FLASH_CS_GPIO_Port, FLASH_CS_Pin, GPIO_PIN_SET);  // cs off
}
//W25QXXд��ֹ
//��WEL����
void W25QXX_Write_Disable(void)
{
	uint8_t TxData,Rxdata;
	TxData = W25X_WriteDisable;
    HAL_GPIO_WritePin(FLASH_CS_GPIO_Port, FLASH_CS_Pin, GPIO_PIN_RESET);	// cs on
	HAL_SPI_TransmitReceive(&FLASH_SPI_HANDLER,&TxData,&Rxdata,1, 1000);  //����д��ָֹ��
    HAL_GPIO_WritePin(FLASH_CS_GPIO_Port, FLASH_CS_Pin, GPIO_PIN_SET);  // cs off
}

#endif

static spi_alock_t sg_flash_app_lock = {0};

void sfud_log_debug(const char *file, const long line, const char *format, ...);

static void spi_lock(const sfud_spi *spi) {
  ((spi_alock_t  *)(spi->user_data))->lock = HAL_LOCKED;
}

static void spi_unlock(const sfud_spi *spi) {
  ((spi_alock_t  *)(spi->user_data))->lock = HAL_UNLOCKED;
}

extern void do_ms_schedule_1ms(void);


#define USE_FLASH_DMA 0
#if 1
/**
 * SPI write data then read data
 */
static sfud_err spi_write_read(const sfud_spi *spi, const uint8_t *write_buf, size_t write_size, uint8_t *read_buf,
        size_t read_size) {
    sfud_err result = SFUD_SUCCESS;

	HAL_StatusTypeDef rc;
    
	 // read and write data
	HAL_GPIO_WritePin(FLASH_CS_GPIO_Port, FLASH_CS_Pin, GPIO_PIN_RESET);	// cs on
	
	if (write_size) 
	{ // write data
	   	if(NULL == write_buf)
	   	{
			result = SFUD_ERR_WRITE;
			goto ERROUT;
		}
		
		#if USE_FLASH_DMA
		rc = HAL_SPI_Transmit_DMA(&FLASH_SPI_HANDLER, (uint8_t *)write_buf, write_size);		
		#else
	   	rc = HAL_SPI_Transmit(&FLASH_SPI_HANDLER, (uint8_t *)write_buf, write_size, 100);
		#endif
		
	   	if (rc != HAL_OK) 
		{
			result = SFUD_ERR_WRITE;
			goto ERROUT;
	   	}
		
		#if USE_FLASH_DMA
	   	while(HAL_SPI_GetState(&FLASH_SPI_HANDLER) == HAL_SPI_STATE_BUSY_TX);
		#endif
	 }
	
	 if (read_size) 
	 {  // read data
		if(NULL == read_buf)
	   	{
			result = SFUD_ERR_READ;
			goto ERROUT;
		}
		
		#if USE_FLASH_DMA
		rc = HAL_SPI_Receive_DMA(&FLASH_SPI_HANDLER, (uint8_t *)read_buf, read_size);
		#else
	   	rc = HAL_SPI_Receive(&FLASH_SPI_HANDLER, (uint8_t *)read_buf, read_size, 100);
	   	#endif
		
	   	if (rc != HAL_OK) 
		{
			result = SFUD_ERR_READ;
			goto ERROUT;
	   	}
		
		#if USE_FLASH_DMA
	   	while(HAL_SPI_GetState(&FLASH_SPI_HANDLER) == HAL_SPI_STATE_BUSY_RX);
		#endif
	 }

ERROUT:	 
	 HAL_GPIO_WritePin(FLASH_CS_GPIO_Port, FLASH_CS_Pin, GPIO_PIN_SET);  // cs off

    return result;
}
#else
static sfud_err spi_write_read(const sfud_spi *spi, const uint8_t *write_buf, size_t write_size, uint8_t *read_buf,
        size_t read_size) 
{
	sfud_err result = SFUD_SUCCESS;

	uint8_t send_data, read_data;
    
	 // read and write data
	HAL_GPIO_WritePin(FLASH_CS_GPIO_Port, FLASH_CS_Pin, GPIO_PIN_RESET);	// cs on
	
	for (size_t i = 0, retry_times; i < write_size + read_size; i++) 
	{
        /* ��д�������е����ݵ� SPI ���ߣ�����д�����д dummy(0xFF) �� SPI ���� */
        if (i < write_size) 
		{
            send_data = *write_buf++;
        } 
		else 
		{
            send_data = SFUD_DUMMY_DATA;
        }
        /* �������� */
		#if USE_FLASH_DMA
        retry_times = 1000;
		while(HAL_SPI_GetState(&FLASH_SPI_HANDLER) == HAL_SPI_STATE_BUSY_TX_RX);
		{
            SFUD_RETRY_PROCESS(NULL, retry_times, result);
        }	
        if (result != SFUD_SUCCESS) 
		{
            goto exit;
        }
		HAL_SPI_TransmitReceive_DMA(&FLASH_SPI_HANDLER,&send_data,&read_data,1);
		#else
		HAL_SPI_TransmitReceive(&FLASH_SPI_HANDLER,&send_data,&read_data,1,1000);
		#endif
        /* д�������е����ݷ�����ٶ�ȡ SPI �����е����ݵ��������� */
        if (i >= write_size) 
		{
            *read_buf++ = read_data;
        }
    }

exit:
	HAL_GPIO_WritePin(FLASH_CS_GPIO_Port, FLASH_CS_Pin, GPIO_PIN_SET);  // cs off

    return result;
}



#endif

#ifdef SFUD_USING_QSPI
/**
 * read flash data by QSPI
 */
static sfud_err qspi_read(const struct __sfud_spi *spi, uint32_t addr, sfud_qspi_read_cmd_format *qspi_read_cmd_format,
        uint8_t *read_buf, size_t read_size) {
    sfud_err result = SFUD_SUCCESS;

    /**
     * add your qspi read flash data code
     */

    return result;
}
#endif /* SFUD_USING_QSPI */

extern void KB_Delay_us(uint32_t us);

static void delay_ms()
{
	HAL_Delay(1);
}
sfud_err sfud_spi_port_init(sfud_flash *flash) {
    sfud_err result = SFUD_SUCCESS;

    if(SFUD_W25Q128BV_DEVICE_INDEX == flash->index)
	{
		sg_flash_app_lock.lock = HAL_UNLOCKED;
		sg_flash_app_lock.hspi = &FLASH_SPI_HANDLER;
		flash->spi.wr = spi_write_read;
		flash->spi.lock = spi_lock;
		flash->spi.unlock = spi_unlock;
		flash->spi.user_data = (void *)&sg_flash_app_lock;
		flash->retry.delay = delay_ms;//do_ms_schedule_1ms;
		flash->retry.times = 2000;
    }
	else
	{
		result = SFUD_ERR_NOT_FOUND;
	}

    return result;
}




