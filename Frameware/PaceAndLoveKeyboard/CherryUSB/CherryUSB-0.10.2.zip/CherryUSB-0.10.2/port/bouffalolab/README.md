[BL702](https://github.com/bouffalolab/bl_mcu_sdk/blob/master/drivers/lhal/src/bflb_usb_v1.c)
[BL616/BL808](https://github.com/bouffalolab/bl_mcu_sdk/blob/master/drivers/lhal/src/bflb_usb_v2.c)
