# Note

## Support Chip List

- NRF5x

## Before Use

- Your should implement `usb_dc_low_level_pre_init`,`usb_dc_low_level_post_init`,`usb_dc_low_level_deinit`.